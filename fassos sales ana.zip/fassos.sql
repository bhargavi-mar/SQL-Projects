create database faasosana;
use faasosana;

drop table if exists driver;
CREATE TABLE driver(driver_id integer,reg_date date); 

INSERT INTO driver (driver_id, reg_date) 
VALUES 
  (1, '2021-01-01'),
  (2, '2021-03-01'),
  (3, '2021-08-01'),
  (4, '2021-01-15');

drop table if exists ingredients;
CREATE TABLE ingredients(ingredients_id integer,ingredients_name varchar(60)); 

INSERT INTO ingredients(ingredients_id ,ingredients_name) 
 VALUES (1,'BBQ Chicken'),
(2,'Chilli Sauce'),
(3,'Chicken'),
(4,'Cheese'),
(5,'Kebab'),
(6,'Mushrooms'),
(7,'Onions'),
(8,'Egg'),
(9,'Peppers'),
(10,'schezwan sauce'),
(11,'Tomatoes'),
(12,'Tomato Sauce');

drop table if exists rolls;
CREATE TABLE rolls(roll_id integer,roll_name varchar(30)); 

INSERT INTO rolls(roll_id ,roll_name) 
 VALUES (1	,'Non Veg Roll'),
(2	,'Veg Roll');

drop table if exists rolls_recipes;
CREATE TABLE rolls_recipes(roll_id integer,ingredients varchar(24)); 

INSERT INTO rolls_recipes(roll_id ,ingredients) 
 VALUES (1,'1,2,3,4,5,6,8,10'),
(2,'4,6,7,9,11,12');

drop table if exists driver_order;
CREATE TABLE driver_order (order_id INT,driver_id INT,pickup_time DATETIME,distance VARCHAR(20),duration VARCHAR(20),cancellation VARCHAR(50));

INSERT INTO driver_order (order_id, driver_id, pickup_time, distance, duration, cancellation)
VALUES
  (1, 1, '2021-01-01 18:15:34', '20km', '32 minutes', ''),
  (2, 1, '2021-01-01 19:10:54', '20km', '27 minutes', ''),
  (3, 1, '2021-03-01 22:30:50', '13.4km', '20 mins', 'NaN'),
  (4, 2, '2021-04-01 13:53:03', '23.4', '40', 'NaN'),
  (5, 3, '2021-08-01 21:10:57', '10', '15', 'NaN'),
  (6, 3, NULL, NULL, NULL, 'Cancellation'),
  (7, 2, '2021-08-01 21:30:45', '25km', '25mins', NULL),
  (8, 2, '2021-10-01 19:35:00', '23.4 km', '15 minute', NULL),
  (9, 2, NULL, NULL, NULL, 'Customer Cancellation'),
  (10, 1, '2021-11-01 18:50:20', '10km', '10 minutes', NULL);
  


drop table if exists customer_orders;
CREATE TABLE customer_orders (order_id INT NOT NULL,customer_id INT NOT NULL,roll_id INT NOT NULL,not_include_items VARCHAR(4) DEFAULT NULL,
extra_items_included VARCHAR(4) DEFAULT NULL,order_date DATETIME NOT NULL);

INSERT INTO customer_orders (order_id, customer_id, roll_id, not_include_items, extra_items_included, order_date)
VALUES
  (1, 101, 1, NULLIF('', ''), NULLIF('', ''), '2021-01-01 18:05:02'),
  (2, 101, 1, NULLIF('', ''), NULLIF('', ''), '2021-01-01 19:00:52'),
  (3, 102, 1, NULLIF('', ''), NULLIF('', ''), '2021-02-01 22:10:23'),
  (3, 102, 2, NULLIF('', ''), NULLIF('NaN', ''), '2021-02-01 22:10:23'),
  (4, 103, 1, NULLIF('4', ''), NULLIF('', ''), '2021-04-01 13:23:46'),
  (4, 103, 1, NULLIF('4', ''), NULLIF('', ''), '2021-04-01 13:23:46'),
  (4, 103, 2, NULLIF('4', ''), NULLIF('', ''), '2021-04-01 13:23:46'),
  (5, 104, 1, NULLIF('', ''), NULLIF('1', ''), '2021-08-01 21:00:29'),
  (6, 101, 2, NULLIF('', ''), NULL, '2021-08-01 21:03:13'),
  (7, 105, 2, NULLIF('', ''), NULLIF('1', ''), '2021-08-01 21:20:29'),
  (8, 102, 1, NULLIF('', ''), NULL, '2021-09-01 19:04:33'),
  (9, 103, 1, NULLIF('4', ''), NULLIF('1,5', ''), '2021-10-01 11:22:59'),
  (10, 104, 1, NULLIF('', ''), NULL, '2021-11-01 18:34:49'),
  (10, 104, 1, NULLIF('2,6', ''), NULLIF('1,4', ''), '2021-11-01 18:34:49');
select * from customer_orders;


select * from customer_orders;
select * from driver_order;
select * from ingredients;
select * from driver;
select * from rolls;
select * from rolls_recipes;

-- A. roll metrics
-- B. driver and customer experience
-- C. ingredient optimisation 
-- D. pricing and ratings

-- A. roll metrics
-- how mamy rolls where ordered
select roll_id,count(roll_id) roll_ordered
from customer_orders
group by roll_id;

-- how mamy unique customer orders where made?
select count(distinct customer_id) unique_customer
from customer_orders;

-- how many successful orders where delivered by each driver?
select driver_id, count(distinct order_id) succesfully_delivered
from driver_order
where cancellation not in ('Cancellation', 'Customer Cancellation')
group by driver_id;

-- how many of each type of roll was delivered
select roll_id,count(roll_id) rolls_sucessfully_delivered
from customer_orders where order_id in(
select order_id from 
(select *, case when cancellation in ('Cancellation', 'Customer Cancellation')
then 'C' else 'NC' end as order_cancel_details
from driver_order)a 
where order_cancel_details ='nc')
group by roll_id;
 
 
 -- how many veg and non-veg rolls where ordered by each customer
 select a.*,b.roll_name from
(select customer_id, roll_id,count(roll_id)
from customer_orders
group by customer_id, roll_id)a 
inner join rolls b using (roll_id);

-- what was the maximum number of rolls delivered in a single order?
select * from 
(select *, rank() over (order by counts desc) rnk from
(select order_id, count(roll_id) counts from
(select * from customer_orders where order_id in 
(select order_id 
from
(select *, case when cancellation in ('Cancellation', 'Customer Cancellation' )
then 'c' else 'nc' end as order_cancel_details 
from driver_order)a
where order_cancel_details ='nc'))b
group by order_id)c)d
where rnk=1;

-- dealing with the data cleaning part 
-- creating a temporary table

with temp_customer_orders (order_id, customer_id,roll_id, not_include_items,extra_items_included,order_date)
as (select order_id, customer_id,roll_id,
case when not_include_items is null or not_include_items =' ' then 0 
else not_include_items end as new_not_include_items,
case when extra_items_included is null or extra_items_included =' ' or extra_items_included ='nan' then 0 
else extra_items_included end as new_extra_items_included,
order_date
from customer_orders) 
,
-- changes in driver_orders table

temp_driver_order(order_id,driver_id,pickup_time,distance, duration, new_cancellation)
as(
select order_id,driver_id,pickup_time,distance, duration,
case when cancellation in ('cancellation', 'customer cancellation') then 0 
else 1 end as new_cancellation
from driver_order)
-- select * from temp_driver_order; 

-- select * from temp_driver_order where new_cancellation !=0;

-- for each customer how many delivered rolls had at least 1 change and how mamy had no changes 
SELECT customer_id, changes_made, COUNT(order_id) AS atleast_one_change 
FROM (
SELECT *, CASE WHEN not_include_items = '0' AND extra_items_included = '0' THEN 'No change'
ELSE 'Change is made' END AS changes_made 
FROM temp_customer_orders 
WHERE order_id IN ( 
SELECT order_id FROM temp_driver_order 
WHERE new_cancellation != 0)) a 
GROUP BY customer_id, changes_made;

-- how many rolls where delivered that had both exclusions and extras?
SELECT  changes_made, COUNT(changes_made) AS total_changes 
FROM (
SELECT *, CASE WHEN not_include_items != '0' AND extra_items_included != '0' THEN 'both included and excluded'
ELSE 'either one included or excluded' END AS changes_made 
FROM temp_customer_orders 
WHERE order_id IN ( 
SELECT order_id FROM temp_driver_order 
WHERE new_cancellation != 0)) a 
GROUP BY changes_made;

-- what was the total number of rolls ordered for each hour of the day?
select a.hours_bucket, count(a.hours_bucket) no_of_rolls_ordered from
(select *,concat(hour(order_date) ,'-', hour(order_date)+1 ) as hours_bucket
 from customer_orders)a
 group by hours_bucket;

-- what was the no of order for each day of week?
select a.day_of_week,  count(distinct a.order_id) as total_orders_placed_on_that_day from
(select *, dayname(order_date)as  day_of_week
 from customer_orders)as a
 group by a.day_of_week;

-- B. driver and customer 
-- what was the average time in minute it took for each driver to arrive at the fassis head quator to pickup the order?
select * from customer_orders;
select * from driver_order;

SELECT do.driver_id,
avg (TIMESTAMPDIFF(MINUTE, TIME(co.order_date), time(do.pickup_time)))as avg_pickup_time
FROM driver_order do
JOIN customer_orders co using(order_id)
WHERE do.cancellation = 0  
GROUP BY do.driver_id;


-- is there any relationship between the number of rolls and how long the order takes to prepare?
   


SELECT customer_id, 
avg(trim(replace(d.distance, 'km', ' '))) as avg_distance 
from customer_orders as c 
inner join driver_order as d using (order_id)
where d.pickup_time is not null
group by customer_id;

-- difference between longest and the shortest delivery times for all orders?
select max(a.duration)- min(a.duration) as difference 
from
(select case when duration like '%min%' then left(duration,locate('m',duration) -1)
else duration end as duration 
from driver_order
where duration is not null)a;

-- what was the average speed for each driver for each delivery and do you notice any trend for these values?

 select a.order_id, a.driver_id, a.distance/a.duration as speed from
(select order_id, driver_id, 
case when duration like '%min%' then left(duration,locate('m',duration) -1)
else duration end as duration ,
trim(replace(distance, 'km', ' '))as distance
from driver_order
where distance is not null)a;

-- trend for these value
 select a.order_id, a.driver_id, a.distance/a.duration as speed , b.no_of_rolls from
(select order_id, driver_id, 
case when duration like '%min%' then left(duration,locate('m',duration) -1)
else duration end as duration ,
trim(replace(distance, 'km', ' '))as distance
from driver_order
where distance is not null)a
inner join (
select order_id, count(roll_id) as no_of_rolls 
from customer_orders
group by order_id)b using(order_id);
-- so for less rolls placed speed is more and for more rolls placed the spped is less

-- another method 
select * from driver_order;
select d.order_id, d.driver_id,
case when duration like '%min%' then left(duration,locate('m',duration) -1)
else duration end as duration ,
trim(replace(distance, 'km', ' '))as distance,
distance/duration as speed ,
count(roll_id)
from driver_order as d
inner join customer_orders as c using(order_id)
where d.distance is not null
group by d.order_id,d.driver_id, d.distance, d.duration;

-- successfuly delivery % for each driver  
--  successfuly delivery % = total order delivered / total order taken
select driver_id,  b.s/b.c from
(select a.driver_id, sum(a.cancel_per) as s ,count(a.driver_id)as c from
(select driver_id , case when cancellation like '%cancel%' then 0 
else 1 end as cancel_per 
from driver_order)a
group by driver_id)b;

-- another way 
select driver_id,
sum(case when cancellation  like '%cancel%' then 0
else 1 end) /count(driver_id) as sucessfully_delivered
from driver_order
group by driver_id;
