create database pizzasales;
use pizzasales;
-- change the datatype of date from text to date format
alter table orders modify column date DATE;

update orders set date = str_to_date(date, '%Y-%m-%d');

-- chang ethe datatype of the time from text to time 
alter table orders modify column time TIME;

-- 1. retrive the total numbers of orders placed 
select count(*) as total_orders from orders;

-- 2. total revenue generated from pizza sales
select sum(a.quantity * b.price) as total_revenue from order_details as a
join pizzas as b using (pizza_id) ;

-- 3. identify the highest priced pizza
select a.name, b.price
from pizza_types as a 
join pizzas as b using(pizza_type_id)
order by b.price desc
limit 1 ;

-- 4. identify the most common pizza size ordered
select b.size, count(a.order_details_id) most_common_pizza_ordered
from order_details as a 
join pizzas as b using(pizza_id)
group by b.size
order by most_common_pizza_ordered desc;

-- 5. List the top 5 most ordered pizza types along with their quantities.
select c.name, sum(a.quantity) mosted_ordered_pizza
from order_details as a
join pizzas as b using (pizza_id) 
join pizza_types as c using (pizza_type_id) 
group by c.name
order by mosted_ordered_pizza desc
limit 5;

-- Join the necessary tables to find the total quantity 
-- of each pizza category ordered.
select c.category , sum(a.quantity) total_quantity
from order_details as a
join pizzas as b using (pizza_id)
join pizza_types as c using (pizza_type_id)
group by c.category 
order by total_quantity desc;

-- Determine the distribution of orders by hour of the day.
select hour(time) hours_of_day, count(order_id) order_count 
from orders
group by hours_of_day;

-- Join relevant tables to find the category-wise distribution of pizzas.
select category , count(*)
 from pizza_types
 group by category;

-- Group the orders by date and
-- calculate the average number of pizzas ordered per day.
select avg(quantity)  as avg_pizza_ordered_perday
from 
(select b.date , sum(a.quantity) as quantity 
from order_details as a
join orders as b using (order_id)
group by b.date 
) as ordered_quantity ;

-- Determine the top 3 most ordered pizza types based on revenue.
select  c.name , sum(a.quantity*b.price) as revenue
from order_details as a
join pizzas as b using(pizza_id)
join pizza_types as c using (pizza_type_id)
group by c.name
order by revenue desc
limit 3;

-- Calculate the percentage contribution of each pizza type 
-- to total revenue.(revnue of category /total revenue)
select c.category , sum(a.quantity*b.price) / (select sum(a.quantity * b.price) as total_revenue from order_details as a
join pizzas as b using (pizza_id)) *100 as percentage_revenue
from order_details as a 
join pizzas as b using (pizza_id)
join pizza_types as c using(pizza_type_id)
group by c.category 
order by percentage_revenue desc;

-- Analyze the cumulative revenue generated over time.
-- (cumulative means : the total revenue a product generates over a specific time period)
select sales.date, 
sum(revenue) over (order by sales.date) as cum_revenue
from 
(select c.date , sum(a.quantity*b.price) as revenue
from order_details as a
join pizzas as b using (pizza_id)
join orders as c using (order_id)
group by c.date ) as sales;

-- Determine the top 3 most ordered pizza types based on 
-- revenue for each pizza category. 
select b.category, b.name, b.revenue
from
(select a.category, a.name, a.revenue,
rank() over(partition by category order by revenue desc) as rnk
from
(select c.category,c.name,  sum(a.quantity*b.price) as revenue
from order_details as a 
join pizzas as b using(pizza_id)
join pizza_types as c using(pizza_type_id) 
group by c.category , c.name
order by revenue desc) a)b
where rnk< 4;



